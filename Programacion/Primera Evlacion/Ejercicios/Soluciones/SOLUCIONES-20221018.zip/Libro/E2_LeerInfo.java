package ejerciciosT5Sintesis;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class E2_LeerInfo {

    public static void capturaInfo() {
        Scanner sc = new Scanner(System.in);
        String info = "";

        while (!info.equals("FIN")) {
            System.out.println("Introduzca la información (FIN para salir):");
            info = sc.nextLine();
            System.out.println("ESCRITO: " + info);
        }
    }

    public static void main(String args[]) {
        capturaInfo();
    }
}
